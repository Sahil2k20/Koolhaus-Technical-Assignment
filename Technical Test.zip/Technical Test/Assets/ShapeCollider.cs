using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShapeCollider : MonoBehaviour
{
    // Shape Points (radius for circle only)
    public Vector2[] points;
    public float radius;

    // Test Point
    public Transform point;

    // Constructors
    public Rectangle rect;
    public Circle circ;

    private void Start()
    {
        // Define a rectangle based on the points provided
        rect = new Rectangle(points[0], points[2]);
    }

    private void Update()
    {
        // Unit test to check collision of a test point in the rectangle
        if (rect.IsPointInsideRect(point.position))
        {
            // Print to console if the test point is within the defined rectangle
            print("Collision");
        }
    }
}


public class Rectangle
{
    // Rectangle Points
    public Vector2[] points = new Vector2[4];

    // Rectangle Constructor
    public Rectangle(Vector2 rectBottomLeft, Vector2 rectTopLeft, Vector2 rectTopRight, Vector2 rectBottomRight)
    {
        points[0] = rectBottomLeft;
        points[1] = rectTopLeft;
        points[2] = rectTopRight;
        points[3] = rectBottomRight;
    }

    // Rectangle Copy Constructor
    public Rectangle(Vector2 rectBottomLeft, Vector2 rectTopRight)
    {
        points[0] = rectBottomLeft;
        points[2] = rectTopRight;
    }

    // Function to check if a point is inside or outside
    public bool IsPointInsideRect(Vector2 point)
    {
        // Check if the test point is within the maximum and minimum dimensions of the rectangle
        // Points[0] is bottom left of the rectangle and points[2] is top right
        if (point.x > points[0].x && point.x < points[2].x && point.y > points[0].y && point.y < points[2].y)
        {
            // Test point is within the defined rectangle
            return true;
        }
        else
        {
            // Test point is not within the defined rectangle
            return false;
        }
    }
}

public class Circle
{
    // Circle Values
    public Vector2 center;
    public float radius;

    // Circle Constructor
    public Circle(Vector2 circCenter, float circRadius)
    {
        center = circCenter;
        radius = circRadius;
    }

    // Function to check if a point is inside or outside
    public bool IsPointInsideCircle(Vector2 point)
    {
        // Check if the test point is within the circle
        if (Mathf.Pow(point.x - center.x, 2) + Mathf.Pow(point.y - center.y, 2) <= Mathf.Pow(radius, 2))
        {
            // Test point is within the defined circle
            return true;
        }
        else
        {
            // Test point is not within the defined circle
            return false;
        }
    }
}
